---
title: "Ananke: a Hugo Theme"
featured_image: '/images/gohugo-default-sample-hero-image.jpg'
description: "The last theme you'll ever need. Maybe."
---
Welcome to my blog with some of my work in progress. I've been working on this book idea. You can read some of the chapters below.
